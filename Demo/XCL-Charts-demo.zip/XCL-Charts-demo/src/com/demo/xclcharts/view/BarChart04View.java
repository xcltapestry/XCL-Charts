package com.demo.xclcharts.view;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.xclcharts.chart.BarChart;
import org.xclcharts.chart.BarData;
import org.xclcharts.chart.DesireLineData;
import org.xclcharts.common.IFormatterDoubleCallBack;
import org.xclcharts.common.IFormatterTextCallBack;
import org.xclcharts.renderer.XChart;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.Log;

public class BarChart04View extends TouchView {
	
	private String TAG = "BarChart04View";
	private BarChart chart = new BarChart();
	//轴数据源
	private List<String> chartLabels = new LinkedList<String>();
	private List<BarData> chartData = new LinkedList<BarData>();
	private List<DesireLineData> mDesireLineDataset = new LinkedList<DesireLineData>();
	
	public BarChart04View(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		chartLabels();
		chartDataSet();
		chartDesireLines();
		chartRender();
	}
	
	private void chartRender()
	{
		try {
			
			//图所占范围大小
			chart.setChartRange(0.0f, 0.0f, getScreenWidth(),getScreenHeight());		
			if(chart.isVerticalScreen())
			{
				chart.setPadding(15, 20, 8, 10);
			}else{
				chart.setPadding(20, 20, 10, 8);
			}
					
			//标题
			chart.setTitle("6月份BMI自测");
			chart.addSubtitle("(XCL-Charts Demo)");	
			//数据源
			chart.setDataSource(chartData);
			chart.setCategories(chartLabels);	
			chart.setDesireLines(mDesireLineDataset);
			
			//图例
			//chart.getLegend().setLeftLegend("BMI值");
			//chart.getLegend().setLowerLegend("日期");
			
			//数据轴
			chart.getDataAxis().setAxisMax(100);
			chart.getDataAxis().setAxisMin(0);
			chart.getDataAxis().setAxisSteps(5);		
			//指隔多少个轴刻度(即细刻度)后为主刻度
			chart.getDataAxis().setDetailModeSteps(4);
			
			//背景网格
			chart.getPlotGrid().showHorizontalLines();
									
			//横向显示柱形,如想看横向显示效果，可打开这两行的注释即可
			//chart.setChartDirection(XEnum.Direction.HORIZONTAL);
			//chart.getPlotGrid().setVerticalLinesVisible(true);
			
			//定义数据轴标签显示格式
			chart.getDataAxis().setLabelFormatter(new IFormatterTextCallBack(){
	
				@Override
				public String textFormatter(String value) {
					// TODO Auto-generated method stub		
					Double tmp = Double.parseDouble(value);
					DecimalFormat df=new DecimalFormat("#0");
					String label = df.format(tmp).toString();				
					return (label);
				}
				
			});
			
			//标签轴旋转40度
			chart.getCategoryAxis().setTickLabelRotateAgent(-45f);
			chart.getCategoryAxis().getAxisTickLabelPaint().setTextSize(15);
			
			//在柱形顶部显示值
			chart.getBar().setItemLabelVisible(true);
			//设定格式
			chart.setItemLabelFormatter(new IFormatterDoubleCallBack() {
				@Override
				public String doubleFormatter(Double value) {
					// TODO Auto-generated method stub
					DecimalFormat df=new DecimalFormat("#0");					 
					String label = df.format(value).toString();
					return label;
				}});
			
			//隐藏Key
			chart.hideKeyLabels();
			
			 //让柱子间没空白
			 chart.getBar().setBarSpacePercentage(0d); //可尝试0.1或0.5各有啥效果噢
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void chartDataSet()
	{
		//标签对应的柱形数据集
		List<Double> dataSeriesA= new LinkedList<Double>();	
	
		double v = 10d;
		for(int i=1;i<31;i++)
		{
			v+=2d;
			dataSeriesA.add(v);
		}
		
		BarData BarDataA = new BarData("",dataSeriesA,(int)Color.rgb(53, 169, 239));			
		chartData.add(BarDataA);
	}
	
	private void chartLabels()
	{		
		for(Integer i=1;i<31;i++)
		{
			chartLabels.add(Integer.toString(i));
		}
	}	
	
	/**
	 * 期望线/分界线
	 */
	private void chartDesireLines()
	{							
		mDesireLineDataset.add(new DesireLineData("正常",20d,(int)Color.rgb(77, 184, 73),3));		
		mDesireLineDataset.add(new DesireLineData("过重",25d,(int)Color.rgb(252, 210, 9),5));
		mDesireLineDataset.add(new DesireLineData("肥胖",28d,(int)Color.rgb(230, 66, 59),6));	
		mDesireLineDataset.add(new DesireLineData("非常肥胖",32d,(int)Color.RED,7));
	}
	
	@Override
    public void render(Canvas canvas) {
        try{
            chart.render(canvas);
        } catch (Exception e){
        	Log.e(TAG, e.toString());
        }
    }

	@Override
	public List<XChart> bindChart() {
		// TODO Auto-generated method stub		
		List<XChart> lst = new ArrayList<XChart>();
		lst.add(chart);		
		return lst;
	}

}
